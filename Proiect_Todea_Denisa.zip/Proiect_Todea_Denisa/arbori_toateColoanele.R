library(rsample)
library(tidyverse)
library(dplyr)
library(rpart)
library(rpart.plot)
library(caret)



AmesDataset <- read.csv("C:/Users/Denisa/Desktop/FacultateAn3Sem2/BigData/Proiect_Todea_Denisa&Sugaru_Iulia_Stefana/data1.csv")


AmesDataset <- select(AmesDataset,AREA, SALE_COND,BUILDTYPE,UTILITY_AVAIL,STREET,MZZONE, N_BEDROOM,N_BATHROOM,N_ROOM,INT_SQFT, REG_FEE, SALES_PRICE, COMMIS, DIST_MAINROAD, PARK_FACIL, QS_BEDROOM, QS_BATHROOM, QS_ROOMS, QS_OVERALL)

AmesDataset <- na.omit(AmesDataset)

AmesDataset %>% 
  select_if(is.numeric) %>%
  gather(metric, value) %>%
  ggplot(aes(value, fill=metric)) +
  geom_density(show.legend = FALSE) + 
  facet_wrap(~metric, scales = "free")

AmesDataset<-AmesDataset %>%
  mutate( N_BEDROOM = factor(N_BEDROOM),
          N_BATHROOM = factor(N_BATHROOM),
          N_ROOM = factor(N_ROOM),
          AREA = factor(AREA),
          SALE_COND= factor(SALE_COND),
          BUILDTYPE = factor(BUILDTYPE),
          UTILITY_AVAIL = factor(UTILITY_AVAIL),
          STREET = factor(STREET),
          MZZONE = factor(MZZONE),
  )



set.seed(123) 
ames_split <- initial_split(AmesDataset, prop = 0.7) 
ames_train <- training(ames_split)
ames_test <- testing(ames_split)


AmesDataset %>% 
  ggplot(aes(SALES_PRICE)) +
  geom_density()



m1 <- rpart(
  formula = SALES_PRICE ~ ., 
  data = ames_train,
  method = "anova" 
)

m1 
rpart.plot(m1) 
m1$cptable  

m2 <- rpart(
  formula = SALES_PRICE ~ ., 
  data = ames_train,
  method = "anova",
  control = list(cp = 0, xval = 10) 
) 


rpart.plot(m2)
plotcp(m2)
abline(v = 8, lty = "dashed") 
m2 

m3 <- rpart(
  formula = SALES_PRICE ~ .,
  data = ames_train, 
  method = "anova",
  control = list(minsplit = 10, maxdepth = 12, xval = 10) #
) 
m3
plotcp(m3)


hyper_grid <- expand.grid(
  minsplit = seq(10, 20, 1),
  maxdepth = seq(8, 15, 1)
)

head(hyper_grid)
models <- list() 
for (i in 1:nrow(hyper_grid)) {
  minsplit <- hyper_grid$minsplit[i]
  maxdepth <- hyper_grid$maxdepth[i]
  models[[i]] <- rpart( 
    formula = SALES_PRICE ~. ,
    data = ames_train,
    method = "anova",
    control = list(minsplit = minsplit, maxdepth = maxdepth)
  )
} 
head(m2$cptable)




get_cp <- function(x) { 
  min <- which.min(x$cptable[,"xerror"])
  cp <- x$cptable[min, "CP"]
}
get_min_error <- function(x) {
  min <- which.min(x$cptable[, "xerror"])
  xerror <- x$cptable[min, "xerror"]
}



mutated_grid <- hyper_grid %>%
  mutate(
    cp = purrr::map_dbl(models, get_cp),
    error = purrr::map_dbl(models, get_min_error)
  )  

view(mutated_grid)

mutated_grid %>%
  arrange(error) %>%
  top_n(-5, wt=error) 

optimal_tree <- rpart(
  formula = SALES_PRICE ~ .,
  data = ames_train,
  method = "anova",
  control = list(minsplit = 11, maxdepth = 13, cp = 0.01)
) 

optimal_tree
pred <- predict(optimal_tree, newdata = ames_test) 
pred
rpart.plot(optimal_tree)
obs <- ames_test$SALES_PRICE 
rmse_value <- sqrt(mean((pred - obs)^2))
rmse_value

