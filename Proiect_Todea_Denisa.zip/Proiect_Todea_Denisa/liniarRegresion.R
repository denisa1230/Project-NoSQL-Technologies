library(tidyverse)
library(modelr)
library(dplyr)
library(tidyr)
library(scatterplot3d)


pop <- read.csv("C:/Users/Denisa/Desktop/FacultateAn3Sem2/BigData/Proiect_Todea_Denisa&Sugaru_Iulia_Stefana/data1.csv")

view(pop)

pop$PARK_FACIL <- ifelse(pop$PARK_FACIL == "Yes", 1, 0)

pop <- na.omit(pop) 


encoded_data <- model.matrix(~ AREA - 1, data = pop)

colnames(encoded_data) <- gsub("AREA", "", colnames(encoded_data))

pop <- cbind(pop, encoded_data)

view(pop)



pop %>%
  select_if(is.numeric) %>%
  gather(metric, value) %>%
  ggplot(aes(value, fill=metric)) +
  geom_density(show.legend = FALSE) +
  facet_wrap(~metric, scales = "free")


price_prediction <- select(pop, INT_SQFT, REG_FEE, SALES_PRICE, COMMIS, DIST_MAINROAD, PARK_FACIL, QS_BEDROOM, QS_BATHROOM, QS_ROOMS, QS_OVERALL, Adyar ,Adyr , `Ana Nagar` , `Ann Nagar` , Chormpet , Chrmpet , Karapakam , Karapakkam , `KK Nagar` , KKNagar , `T Nagar` , TNagar , Velachery , Velchery) 

view(price_prediction)


mod_sales_ALL <- lm(SALES_PRICE ~ REG_FEE + COMMIS + INT_SQFT + DIST_MAINROAD + PARK_FACIL + QS_BEDROOM + QS_BATHROOM + QS_ROOMS + QS_OVERALL + Adyar + Adyr + `Ana Nagar` + `Ann Nagar` + Chormpet + Chrmpet + Karapakam + Karapakkam + `KK Nagar` + KKNagar + `T Nagar` + TNagar + Velachery + Velchery, data = price_prediction)

summary(mod_sales_ALL)


mod_sales <- lm(SALES_PRICE ~ REG_FEE + COMMIS + INT_SQFT + PARK_FACIL + Adyar + Karapakam + Karapakkam + `KK Nagar` + Velachery, data = price_prediction)

summary(mod_sales)

price_prediction %>%
  ggplot(aes(INT_SQFT, SALES_PRICE)) + geom_point() + geom_smooth()

price_prediction %>%
  ggplot(aes(PARK_FACIL, SALES_PRICE)) + geom_point()

price_prediction %>%
  ggplot(aes(REG_FEE, SALES_PRICE)) + geom_point() + geom_smooth()

price_prediction %>%
  ggplot(aes(COMMIS, SALES_PRICE)) + geom_point() + geom_smooth()


#learn the linear regression of price on squareMeters

mod_price_INT_SQFT <- lm(data = price_prediction, SALES_PRICE ~ INT_SQFT)   

summary(mod_price_INT_SQFT) #0.3754

mod_price_REG_FEE <- lm(data = price_prediction, SALES_PRICE ~ REG_FEE)   
summary(mod_price_REG_FEE) #cel mai bun 0.7714

mod_price_COMMIS <- lm(data = price_prediction, SALES_PRICE ~ COMMIS)   
summary(mod_price_COMMIS) #0.3935

mod_price_PARK_FACIL <- lm(data = price_prediction, SALES_PRICE ~ PARK_FACIL)   
summary(mod_price_PARK_FACIL) #0.0216

mod_price_Adyar <- lm(data = price_prediction, SALES_PRICE ~ Adyar)   
summary(mod_price_Adyar) #0.02508

mod_price_Karapakam <- lm(data = price_prediction, SALES_PRICE ~ Karapakam)   
summary(mod_price_Karapakam) #0.0002482

mod_price_KK_Nagar <- lm(data = price_prediction, SALES_PRICE ~ `KK Nagar`)   
summary(mod_price_KK_Nagar) #0.03795

mod_price_Velachery <- lm(data = price_prediction, SALES_PRICE ~ Velachery)   
summary(mod_price_Velachery) #0.000286

mod_price_Karapakkam <- lm(data = price_prediction, SALES_PRICE ~ Karapakkam)   
summary(mod_price_Karapakkam) #0.211


#comanda confint
confint(mod_price_INT_SQFT) #[4891.592, 5194.296]

confint(mod_price_REG_FEE)#[22.8372 2.342506e+01]

confint(mod_price_COMMIS)#[2.914326e+01 30.8872]

confint(mod_price_PARK_FACIL)#[ 933858.8  1281909]


#plot the data against the learned regression line
#REG_FEE
grid_REG_FEE <- price_prediction %>%  
  data_grid(REG_FEE = seq_range(REG_FEE, 100)) %>%
  add_predictions(mod_price_REG_FEE, "SALES_PRICE")

ggplot(price_prediction, aes(REG_FEE, SALES_PRICE)) + 
  geom_point() + 
  geom_line(data = grid_REG_FEE, color = "red", linewidth = 1)

#COMMIS
grid_COMMIS <- price_prediction %>%  
  data_grid(COMMIS = seq_range(COMMIS, 100)) %>%
  add_predictions(mod_price_COMMIS, "SALES_PRICE")

ggplot(price_prediction, aes(COMMIS, SALES_PRICE)) + 
  geom_point() +  
  geom_line(data = grid_COMMIS, color = "red", linewidth = 1)

#INT_SQFT

grid_INT_SQFT <- price_prediction %>%  
  data_grid(INT_SQFT = seq_range(INT_SQFT, 100)) %>%
  add_predictions(mod_price_INT_SQFT, "SALES_PRICE")

ggplot(price_prediction, aes(INT_SQFT, SALES_PRICE)) + 
  geom_point() +  
  geom_line(data = grid_INT_SQFT, color = "red", linewidth = 1) 

#PARK_FACIL
grid_PARK_FACIL <- price_prediction %>%  
  data_grid(PARK_FACIL = seq_range(PARK_FACIL, 100)) %>%
  add_predictions(mod_price_PARK_FACIL, "SALES_PRICE")

ggplot(price_prediction, aes(PARK_FACIL, SALES_PRICE)) + 
  geom_point() +  
  geom_line(data = grid_PARK_FACIL, color = "red", linewidth = 1) 

#desenare plan 
s3d <- scatterplot3d(price_prediction$REG_FEE, price_prediction$COMMIS, price_prediction$INT_SQFT,price_prediction$SALES_PRICE, type="p") 

#newsppeling
newspendings <- tibble(
  REG_FEE = 370522,
  COMMIS = 113123,
  INT_SQFT=1344, 
  PARK_FACIL=1,
  `KK Nagar`=1,
  Adyar=0,
  Karapakam=0,
  Velachery=0,
  Karapakkam=0
  
)
predict(mod_sales, newdata = newspendings, interval = "confidence") 
predict(mod_sales, newdata = newspendings, interval = "prediction")

